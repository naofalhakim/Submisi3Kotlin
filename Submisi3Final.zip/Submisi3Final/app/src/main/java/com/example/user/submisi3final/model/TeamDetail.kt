package com.example.user.submisi3final.model

import com.google.gson.annotations.SerializedName

data class TeamDetail(
    @SerializedName("strTeamBadge")
    var strTeamBadge: String? = null

)