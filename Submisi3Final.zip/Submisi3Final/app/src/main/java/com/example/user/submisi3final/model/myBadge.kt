package com.example.user.submisi3final.model

data class myBadge(
    val teams : List<TeamDetail>)