package com.example.user.submisi3final.model

data class myLigaModel(
    val events : List<TeamMatch>)